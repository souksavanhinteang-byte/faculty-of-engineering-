# ເວັບແນະນຳຄະນະວິສະວະກຳສາດ ມຊ

ໂຄງການ React + TypeScript + Vite ນີ້ເປັນໜ້າເວັບແນະນຳສອງພາສາ (ລາວ/English) ສຳລັບຄະນະວິສະວະກຳສາດ, ມະຫາວິທະຍາໄລແຫ່ງຊາດລາວ. ເປັນໂຄງການທົດລອງ ບໍ່ແມ່ນເວັບທາງການ.

## ໂຄງສ້າງໄຟລ໌

- `src/App.tsx` — ໂຄງສ້າງໜ້າເວັບ, ເມນູ, ພາກວິຊາ, ແລະ lightbox.
- `src/content.ts` — ຂໍ້ຄວາມສອງພາສາ ແລະລາຍການ 10 ພາກວິຊາ; ແກ້ຂໍ້ຄວາມຢູ່ນີ້.
- `src/components/EngineeringScene.tsx` — ພາບ 3D Three.js, ປຸ່ມ Explode/Assemble ແລະ Reset.
- `src/styles.css` — ສີ, ຟອນ, ການຈັດວາງ responsive.
- `public/picture/` — ສຳເນົາ logo ແລະຮູບພາບທີ່ໃຊ້ໃນເວັບ. ໄຟລ໌ໃນ `../picture/` ຕົ້ນສະບັບບໍ່ໄດ້ຖືກແກ້.

## ການຕິດຕັ້ງ

ຕ້ອງມີ Node.js ຮຸ່ນປັດຈຸບັນ (ແນະນຳ 20+). ເປີດ Terminal ຢູ່ໃນໂຟນເດີ `code` ແລ້ວລັນ:

```powershell
npm install
npm run dev
```

Vite ຈະສະແດງ local URL (ປົກກະຕິແມ່ນ `http://localhost:5173`) ໃຫ້ເປີດໃນ browser.

ສ້າງ production build ແລະເບິ່ງຜົນ:

```powershell
npm run build
npm run preview
```

ກວດ TypeScript ເທົ່ານັ້ນ:

```powershell
npm run check
```

## ແກ້ໄຂເນື້ອຫາ ແລະຮູບ

ເພື່ອປ່ຽນຮູບ, ວາງໄຟລ໌ໃໝ່ໃນ `public/picture/` ແລ້ວແກ້ path ໃນ `src/App.tsx` ຫຼື `src/content.ts`. ຄວນຮັກສາສັດສ່ວນ logo; CSS ກຳນົດ `object-fit: contain` ໄວ້ແລ້ວ.

ແກ້ຄຳແປຂອງໜ້າເວັບໄດ້ທີ່ `src/content.ts`: ແຕ່ລະລາຍການມີ `lo` ແລະ `en`. ເນື້ອຫາຄະນະທີ່ກວດຢືນຢັນແລ້ວ, ລາຍການ `departments`, ລິ້ງທາງການ ແລະ ບັນທຶກແຫຼ່ງຂໍ້ມູນ ຢູ່ໃນ `src/faculty-content.ts`. ກ່ອນເພີ່ມລາຍລະອຽດຫຼັກສູດ ໃຫ້ອ່ານໜ້າທາງການ ແລະ ອັບເດດບັນທຶກໃນ `docs/content-sources.md`.

ສີຫຼັກຢູ່ຕົ້ນ `src/styles.css` ໃນ `:root` (`--paper`, `--blue`, `--gold`, `--gold-ink`, `--muted`, `--line`, `--ink`).

## ພາບ 3D

`EngineeringScene.tsx` builds a conceptual structural pavilion from Three.js geometry: floor slabs, steel columns, cross bracing, stairs, glass balustrades, and a gabled roof truss. It is an illustration, not a model of an actual campus building.

Drag to rotate on desktop, use arrow keys when the model has keyboard focus, or rotate with two fingers on touch screens. Single-finger swipes scroll the page. Explode/Assemble separates the floors and roof, with automatic camera fitting; Reset returns to the original view. Reduced-motion users get immediate state changes.

The scene loads separately, caps device pixel ratio, and renders on demand. It suspends outside the viewport and in hidden tabs, observes its own size, and disposes graphics resources on unmount. Browsers without WebGL receive an SVG illustration with working model controls.

## Design and interaction

The design uses warm ivory, deep blue, and muted gold; self-hosted Manrope, DM Sans, and Noto Sans Lao; authentic supplied campus photography; and individual blueprint illustrations for the department explorer. No third-party font request is needed. Original photos in `../picture/` are preserved.

Motion for React provides staggered entrances, scroll reveals, department transitions, gallery fades, and subtle campus-photo parallax. The site respects `prefers-reduced-motion`. Lao is the initial language; the language switch persists the visitor's choice when local storage is available.

The department explorer supports Arrow Up/Down and Home/End on desktop, and a native select on mobile. The native gallery dialog traps focus, supports Arrow Left/Right, closes with Escape or a backdrop click, locks background scrolling, and restores focus to the photo trigger. Section links and the back-to-top control use native anchors.

## Browser verification

The Playwright suite uses installed Google Chrome (`channel: 'chrome'`). Start the local server in one terminal, then run:

```powershell
npm run test:e2e
```

Tests cover both languages, persistence, all ten departments, navigation, the mobile menu and selector, gallery controls and focus restoration, 3D mouse and keyboard controls, the WebGL fallback, reduced motion, and overflow from 320px to 1920px. An axe audit checks WCAG A/AA rules on desktop, mobile, and the open gallery. Review screenshots are saved under the ignored `test-results/` directory.

For a production preview, run `npm run build` and `npm run preview -- --host 127.0.0.1` in separate terminals, then set `PLAYWRIGHT_BASE_URL` to the preview URL before running the tests. React, Motion, the Three.js core, and the renderer have separate cacheable build chunks.

Run `npm run format` to format the source. The project is a presentation website; official programme information and faculty announcements are linked through the existing official channels.

## Verified faculty content

The faculty introduction, university vision, two-milestone timeline, ten departments, selected bachelor majors, facilities/research/cooperation examples, student information links, archived seminar article, and contact details are centralized in `src/faculty-content.ts`. Source URLs, access dates, editorial decisions and unresolved conflicts are documented in [docs/content-sources.md](docs/content-sources.md). The site links to the corresponding official Lao or English page.

Some department pages contain placeholders. Their descriptions are explicitly labeled general field explanations, and no unsupported curriculum is supplied. News has a real publication date and archive label; student links do not promise current scholarships, timetables or service availability. Existing photographs are not identified as specific facilities or events. Body and campus ResizeObservers refresh Motion’s scroll measurements after language, font and content-size changes.

Read-only verification helpers:

```powershell
node scripts/read-official.mjs https://fe-nuol.edu.la/en/department/
node scripts/inspect-contact.mjs
node scripts/check-official-links.mjs
```

The helpers require network access and installed Chrome. The live link checker additionally uses Node 24+ to import the typed source registry directly. They report evidence for editorial review; they do not automatically change content, verify open opportunities, or send email.
